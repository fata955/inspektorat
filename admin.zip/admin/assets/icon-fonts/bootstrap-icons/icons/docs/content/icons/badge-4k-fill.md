---
title: Badge 4k fill
categories:
  - Badges
tags:
  - 4k
  - display
  - resolution
  - retina
---
